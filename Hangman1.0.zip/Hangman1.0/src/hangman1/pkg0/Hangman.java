/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hangman1.pkg0;

import java.util.Scanner;
import java.util.Arrays;

public class Hangman extends javax.swing.JFrame {
    static int currenttry = 0;
    
    public Hangman() {
        initComponents();
        initComponents2();
    }
    
    private void initComponents2() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jPasswordField1 = new javax.swing.JPasswordField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("___");

        jLabel2.setText("___");

        jLabel3.setText("___");

        jLabel4.setText("___");

        jLabel5.setText("___");

        jLabel6.setText("___");

        jLabel7.setText("___");

        jLabel8.setText("___");

        jPasswordField1.addActionListener((java.awt.event.ActionEvent evt) -> {
            jPasswordField1ActionPerformed(evt);
        });

        jLabel9.setText("RightOrWrong?");

        jLabel10.setText("Your Word");

        jLabel11.setText("#ofGuesses");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(174, 174, 174)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel7)
                .addGap(18, 18, 18)
                .addComponent(jLabel8)
                .addContainerGap(25, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(133, 133, 133)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel9)
                .addGap(124, 124, 124))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jPasswordField1, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(87, 87, 87))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addGap(57, 57, 57))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(94, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(jLabel10))
                .addGap(36, 36, 36)
                .addComponent(jPasswordField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(93, 93, 93)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7)
                    .addComponent(jLabel8))
                .addGap(38, 38, 38)
                .addComponent(jLabel11)
                .addContainerGap())
        );

        pack();
    }
    
    // The player's input and how the output works
        private void jPasswordField1ActionPerformed(java.awt.event.ActionEvent evt) {                                                
        jLabel10.setText(finalizedWord);
        int position; 
        Scanner input = new Scanner(System.in);
        String theirInput = jPasswordField1.getText();
        if (finalizedWord.regionMatches(0,theirInput,0,0)) {
            position=finalizedWord.indexOf(theirInput);
            jLabel9.setText("Correct");
            switch (position) {
                case 0: 
                    jLabel1.setText(theirInput);
                    break;
                case 1: 
                    jLabel2.setText(theirInput);
                    break;
                case 2:
                    jLabel3.setText(theirInput);
                    break;
                case 3: 
                    jLabel4.setText(theirInput);
                    break; 
                case 4:
                    jLabel5.setText(theirInput);
                    break;
                case 5:
                    jLabel6.setText(theirInput);
                    break;
                case 6:
                    jLabel7.setText(theirInput);
                    break;
                case 7:
                    jLabel8.setText(theirInput);
                    break;
                default: 
                    ++numberOfWrongs;
                    jLabel9.setText("Wrong");
                    jLabel11.setText("Number of Wrong geuss: " +numberOfWrongs);
                    break;
            }
        }
        jPasswordField1.setText("");
    }               
    
    private void noPerson(){ // The deafault begining version of the Hangman
        
        Body.setVisible(false);
        Head.setVisible(false);
        FirstArm.setVisible(false);
        FirstLeg.setVisible(false);
        SecondArm.setVisible(false);
        SecondLeg.setVisible(false);
        Stand.setVisible(true);
    }
    
    
    public void drawPerson(){ /* The part of the code when the limbs and hangman appears,
        if the player picks the wrong letter */
        switch(currenttry){
            case 0: // The start of the game where it's just the stand that is visible
                Body.setVisible(false);
                Head.setVisible(false);
                FirstArm.setVisible(false);
                FirstLeg.setVisible(false);
                SecondArm.setVisible(false);
                SecondLeg.setVisible(false);
                Stand.setVisible(true);
            case 1: //If the player enters a letter that's not in the word the head and the body appear
                Body.setVisible(true);
                Head.setVisible(true);
                FirstArm.setVisible(false);
                FirstLeg.setVisible(false);
                SecondArm.setVisible(false);
                SecondLeg.setVisible(false);
                Stand.setVisible(true);
            case 2: // The 2nd letter the player gets wrong, then the arms appear
                Body.setVisible(true);
                Head.setVisible(true);
                FirstArm.setVisible(true);
                FirstLeg.setVisible(false);
                SecondArm.setVisible(true);
                SecondLeg.setVisible(false);
                Stand.setVisible(true);
            default: // The 3rd letter the player gets wrong, then the legs appear
                Body.setVisible(true);
                Head.setVisible(true);
                FirstArm.setVisible(true);
                FirstLeg.setVisible(true);
                SecondArm.setVisible(true);
                SecondLeg.setVisible(true);
                Stand.setVisible(true);
        }
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
 * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Stand = new javax.swing.JLabel();
        Head = new javax.swing.JLabel();
        Body = new javax.swing.JLabel();
        FirstArm = new javax.swing.JLabel();
        SecondArm = new javax.swing.JLabel();
        FirstLeg = new javax.swing.JLabel();
        SecondLeg = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Body.setVisible(false);
        Head.setVisible(false);
        FirstArm.setVisible(false);
        FirstLeg.setVisible(false);
        SecondArm.setVisible(false);
        SecondLeg.setVisible(false);
        Stand.setVisible(true);
        Stand.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Stand.png"))); // NOI18N

        Head.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Head.png"))); // NOI18N
        Head.setText("jLabel1");

        Body.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Body.png"))); // NOI18N
        Body.setText("jLabel2");

        FirstArm.setIcon(new javax.swing.ImageIcon(getClass().getResource("/First Arm.png"))); // NOI18N
        FirstArm.setText("jLabel3");

        SecondArm.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Second Arm.png"))); // NOI18N
        SecondArm.setText("jLabel1");

        FirstLeg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/First Leg.png"))); // NOI18N
        FirstLeg.setText("jLabel1");

        SecondLeg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Second Leg.png"))); // NOI18N
        SecondLeg.setText("jLabel1");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(FirstLeg, javax.swing.GroupLayout.PREFERRED_SIZE, 490, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(Head, javax.swing.GroupLayout.PREFERRED_SIZE, 610, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(Stand, javax.swing.GroupLayout.PREFERRED_SIZE, 590, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(SecondArm, javax.swing.GroupLayout.PREFERRED_SIZE, 520, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(SecondLeg, javax.swing.GroupLayout.PREFERRED_SIZE, 490, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(FirstArm, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(20, 20, 20)
                            .addComponent(Body, javax.swing.GroupLayout.PREFERRED_SIZE, 510, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(3, 3, 3))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(260, 260, 260)
                        .addComponent(FirstLeg, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(100, 100, 100)
                        .addComponent(Head, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addComponent(Stand, javax.swing.GroupLayout.PREFERRED_SIZE, 386, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(160, 160, 160)
                        .addComponent(Body, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(190, 190, 190)
                        .addComponent(SecondArm, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(270, 270, 270)
                        .addComponent(SecondLeg, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(FirstArm, javax.swing.GroupLayout.PREFERRED_SIZE, 470, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
   
    public static void main(String args[]) {
        
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Hangman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        
        //</editor-fold>
        
        
        
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new Hangman().setVisible(true);
        });
    }
      
    private static String wordCreated () {
        // The words that we are using for the game and randomising them
        String letters1 = "Country"; 
        String letters2 = "grateful"; 
        String letters3 = "Monster";
        String letters4 = "Chipmuck";
        String letters5 = "Comeback";
        String letters6 = "Jumbling";
        String letters7 = "Kingdom";
        String letters8 = "Jackpot";
        String letters9 = "Equality";
        String letters10 = "Document";
        String theWord = null;
        int mx = (int)(Math.random()*10);
        switch (mx){
            case 1: 
                theWord = letters1;
                break;
            case 2:
                theWord = letters2; 
                break;
            case 3:
                theWord = letters3;
                break;
            case 4:
                theWord = letters4;
                break;
            case 5:
                theWord = letters5;
                break;
            case 6:
                theWord = letters6;
                break;
            case 7:
                theWord = letters7;
                break;
            case 8:
                theWord = letters8;
                break;
            case 9:
                theWord = letters9;
                break;
            default: 
                theWord = letters10; 
                break;
        }
        return theWord;
    }
    
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Body;
    private javax.swing.JLabel FirstArm;
    private javax.swing.JLabel FirstLeg;
    private javax.swing.JLabel Head;
    private javax.swing.JLabel SecondArm;
    private javax.swing.JLabel SecondLeg;
    private javax.swing.JLabel Stand;
    // End of variables declaration//GEN-END:variables

    
// Variables declaration - do not modify 
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPasswordField jPasswordField1;
    final String finalizedWord = wordCreated();
    int numberOfWrongs=0;
    // End of variables declaration 
}

