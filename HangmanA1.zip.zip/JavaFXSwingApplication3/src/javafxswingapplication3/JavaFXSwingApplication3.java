/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxswingapplication3;

import java.awt.BorderLayout;
import java.awt.Dimension;
import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javax.swing.JApplet;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import java.util.Scanner; 
import java.util.ArrayList;
import java.util.Arrays;

class ApartmentNo {
    int x; 
    ApartmentNo(int i) {
    x = i;
    }
}

class Ay {
    int a; 
    Ay (int v) {
        a=v; 
    }
}   // to replace a1, a2, a3, etc.

public class JavaFXSwingApplication3 extends JApplet {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        //ArrayList<Integer> NoBelowAverageApartments = new ArrayList<>(); 
        int [] NoBelowAverageApartments = {};
        System.out.println("how many apartments are there: ");
        int NumApart = input.nextInt(); 
        //ArrayList<Integer> thelist = new ArrayList<>();
        int [] thelist; 
        int turn = 0;
        int total = 0;
        do{
            
            int No = 1; 
            System.out.println("How many people in the apartment: a" + No);
            int userInput = input.nextInt();
            thelist = new int [userInput];
            int taken = userInput; 
            total = total + taken; 
            ++turn;
            ++No; 
        } while (turn != NumApart);
        System.out.println("");
        int theAverage = Average (total, NumApart);
        System.out.println("The average amount of people per apartment is: " + theAverage);
        int [] theBelowAverage = Belowaverage (theAverage, thelist, NumApart);
        
        System.out.println("The apartments that have below average amount of occupants are apartments No. "+ Arrays.toString(theBelowAverage));
    }    
    public static int Average(int theNumberOfPeople, int theNumberOfApartments) {
        
        int theGrandAverage = theNumberOfPeople/theNumberOfApartments;
        return theGrandAverage; 
    }
    
    
    public static int [] Belowaverage(int TheAverage, int[] TheTaken, int theNumberOfApartments1){
        
        int arrayNo;
        int ndTurn = 0;
        int [] BelowAverageApartments = {};
        do {
            arrayNo = TheTaken[ndTurn];
            
            if (arrayNo<=TheAverage) {
                BelowAverageApartments = new int [arrayNo];
            }
            else {
                System.out.println("");
            }
            ++ndTurn;        
        } while (ndTurn!=theNumberOfApartments1);
        
        return BelowAverageApartments; 
    }
}
/*
ApartmentNo a1 = new ApartmentNo (1);
        ApartmentNo a2 = new ApartmentNo (2);
        ApartmentNo a3 = new ApartmentNo (3);
        ApartmentNo a4 = new ApartmentNo (4);
        ApartmentNo a5 = new ApartmentNo (5);
        ApartmentNo a6 = new ApartmentNo (6);
        ApartmentNo a7 = new ApartmentNo (7);
*/

