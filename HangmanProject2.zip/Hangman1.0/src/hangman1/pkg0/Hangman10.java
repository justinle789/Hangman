/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hangman1.pkg0;
import java.util.*;

/**
 *
 * @author israe
 */
public class Hangman10 {
    
    public static void random8Letter(){
        String[] words8L= {"blizzard","dazzling","backpack","equalize","exorcise","chipmuck","original","periodic"};
        int random = (int)(Math.random()*8);
        System.out.println("The random word is: " + words8L[random]);
        
    }
public static void letterChecker(){
    
    
}
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        random8Letter();
        
    }
    
}
