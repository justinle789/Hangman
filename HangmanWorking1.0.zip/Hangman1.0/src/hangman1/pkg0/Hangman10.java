/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hangman1.pkg0;
import java.awt.event.ActionEvent;
import java.util.Scanner; 
import java.awt.BorderLayout;
import java.awt.Dimension;
import javafx.application.Platform;
import javafx.embed.swing.JFXPanel;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javax.swing.JApplet;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
/**
 *
 * @author israe
 */
public class Hangman10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);
        String letters1 = "orginal";
        String letters2 = "grateful"; 
        String letters3 = "periodic"; 
        
        String theword; 
        int mx= (int)(3*Math.random());
        switch (mx){
            case 1: 
                theword = letters1; 
                break;
            case 2:
                theword = letters2; 
                break;
            case 3: 
                theword = letters3; 
                break;
    }   
    
    private void createScene(){ 
        textField tx = new textField(35);
        tx.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override    
        public void handle(ActionEvent event) {
                System.out.println("Hello World!");
        }
    }
}
